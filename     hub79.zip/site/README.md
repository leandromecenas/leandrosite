# HUB 79 Imobiliária — site

Site estático. Não precisa de build, npm ou servidor — são arquivos HTML puros.

## Estrutura

```
index.html      → Home (hero animada, empreendimentos, imóveis, equipe, contato)
imoveis.html    → Todos os imóveis, com filtros por tipo e bairro
support.js      → Runtime que renderiza as páginas
assets/         → Logos, fotos da hero e fotos da equipe (WebP)
```

## Publicar no GitHub Pages

1. Crie um repositório e envie o conteúdo desta pasta na raiz.
2. No repositório: **Settings → Pages → Source: Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. Em poucos minutos o site fica no ar em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

Para domínio próprio, adicione um arquivo `CNAME` na raiz com o domínio (ex.: `hub79.com.br`) e aponte o DNS para o GitHub Pages.

## Testar localmente

Abrir `index.html` direto no navegador funciona. Se preferir servir:

```
python3 -m http.server
```

e acesse `http://localhost:8000`.

## O que ainda é conteúdo de exemplo

Trocar antes de publicar:

- **WhatsApp**: todos os botões apontam para `https://wa.me/5579000000000` — buscar e substituir pelo número real.
- **Imóveis e empreendimentos**: nomes, bairros, áreas e valores estão no início do `<script>` de cada página (constantes `EMP` e `IMOVEIS`).
- **Fotos dos imóveis**: hoje são imagens do Unsplash carregadas por URL. Substituir pelos arquivos reais em `assets/`.
- **Endereço e e-mail**: rodapé e seção de contato.

As fotos da equipe e as imagens da hero já são as reais, em WebP.

## Responsivo

Uma única página atende desktop e celular. No mobile:

- menu em tela cheia pelo botão do topo;
- foto da hero expande até ocupar a tela inteira, e a logo se forma sem separar HUB / 79;
- carrossel navega por toque (arrastar) e pelos pontos;
- filtros dos imóveis em faixas de rolagem horizontal.
